# Grocery Demand & Operations Analysis

## Objective
Analyze grocery order data to find demand patterns and operational issues.

## Tools Used
- SQL
- Excel

## Key Insights
- Identified top selling products
- Found cancellation rate
- Analyzed city-wise demand
