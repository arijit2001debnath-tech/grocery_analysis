
-- Top selling products
SELECT product_name, SUM(quantity) as total_sold
FROM orders
GROUP BY product_name
ORDER BY total_sold DESC;

-- Orders by city
SELECT city, COUNT(*) as total_orders
FROM orders
GROUP BY city;

-- Cancellation rate
SELECT 
(SUM(CASE WHEN status='cancelled' THEN 1 ELSE 0 END)*100.0)/COUNT(*) 
AS cancel_rate
FROM orders;
